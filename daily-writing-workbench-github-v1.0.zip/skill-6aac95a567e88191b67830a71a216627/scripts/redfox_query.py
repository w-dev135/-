#!/usr/bin/env python3
"""Minimal RedFoxHub query adapter. API key is read only from environment."""
import argparse, json, os, sys, urllib.request, urllib.error

ENDPOINTS={
 'xhs': 'https://redfox.hk/story/api/xhs/search/search',
 'gzh': 'https://redfox.hk/story/api/gzhData/searchArticle',
}

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--platform',choices=ENDPOINTS,required=True)
 p.add_argument('--keyword',required=True)
 p.add_argument('--page-num',type=int,default=1);p.add_argument('--page-size',type=int,default=10)
 p.add_argument('--start-date',default='');p.add_argument('--end-date',default='')
 p.add_argument('--endpoint',default='')
 a=p.parse_args(); key=os.environ.get('REDFOX_API_KEY','').strip()
 if not key: p.error('未找到 REDFOX_API_KEY；请在本机环境变量中配置，不要把密钥写入笔记或命令历史。')
 payload={'keyword':a.keyword,'pageNum':a.page_num,'pageSize':a.page_size,'startDate':a.start_date,'endDate':a.end_date}
 req=urllib.request.Request(a.endpoint or os.environ.get('REDFOX_'+a.platform.upper()+'_ENDPOINT',ENDPOINTS[a.platform]),data=json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','X-API-KEY':key},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=30) as r: result=json.loads(r.read().decode('utf-8'))
 except urllib.error.HTTPError as e: p.error(f'接口返回HTTP {e.code}；请核对接口、余额和参数（未输出密钥）')
 except (urllib.error.URLError,TimeoutError) as e: p.error(f'网络请求失败：{e.reason if hasattr(e,"reason") else e}')
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
