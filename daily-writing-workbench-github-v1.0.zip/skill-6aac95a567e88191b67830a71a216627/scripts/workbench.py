#!/usr/bin/env python3
"""Local, non-destructive writing progress register. No network calls."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import tempfile
import uuid

STATES = ['灵感','选题卡','大纲','草稿','待核验','待发布','已发布','已复盘']
DIRS = ['00_写作入口','01_可公开素材','02_选题池','03_写作中','04_待发布','05_已发布','06_复盘','07_模板与风格']

def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')

def read(path):
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('version') != 1 or not isinstance(data.get('articles'),dict):
        raise ValueError('状态格式不支持，请保留原文件并检查')
    return data

def save(path,data):
    data['updated_at']=stamp()
    fd,tmp=tempfile.mkstemp(prefix='state-',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
            f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True,type=Path)
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('init');sub.add_parser('list')
    n=sub.add_parser('new');n.add_argument('title');n.add_argument('--next',default='整理一张已获准使用的素材卡')
    s=sub.add_parser('show');s.add_argument('id')
    u=sub.add_parser('update');u.add_argument('id');u.add_argument('--status',choices=STATES);u.add_argument('--next');u.add_argument('--draft');u.add_argument('--note');u.add_argument('--publication-confirmed',action='store_true')
    a=p.parse_args();root=a.root.expanduser().resolve()
    if not a.root.expanduser().is_absolute():p.error('--root需要绝对路径')
    state_dir=root/'.writing-workbench';path=state_dir/'state.json'
    try:
        if a.cmd=='init':
            root.mkdir(parents=True,exist_ok=True)
            state_dir.mkdir(exist_ok=True)
        elif not path.is_file():
            raise ValueError('尚未初始化，先运行init')
        lock=state_dir/'write.lock'
        writing=a.cmd in ('init','new','update');locked=False
        try:
            if writing:
                try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                except FileExistsError:raise ValueError('其他写入可能正在进行；未修改状态。确认没有运行任务后再处理锁文件')
                os.close(fd);locked=True
            if a.cmd=='init':
                data=read(path) if path.exists() else {'version':1,'articles':{}}
                for folder in DIRS:(root/folder).mkdir(exist_ok=True)
                if not path.exists():save(path,data)
                result={'root':str(root),'articles':len(data['articles']),'status':'已初始化，保留已有文件'}
            else:
                data=read(path)
                if a.cmd=='new':
                    if not a.title.strip():raise ValueError('标题不能为空')
                    aid=uuid.uuid4().hex[:12]
                    item={'id':aid,'title':a.title,'status':'灵感','next':a.next,'draft':None,'created_at':stamp(),'updated_at':stamp(),'history':[]}
                    data['articles'][aid]=item;save(path,data);result=item
                elif a.cmd=='list':result=list(data['articles'].values())
                else:
                    if a.id not in data['articles']:raise ValueError('未找到文章ID')
                    item=data['articles'][a.id]
                    if a.cmd=='update':
                        if a.status in ('已发布','已复盘') and item['status'] not in ('已发布','已复盘') and not a.publication_confirmed:
                            raise ValueError('需实际发布确认才能设置此状态')
                        if a.draft is not None:
                            candidate=(root/a.draft).resolve()
                            if not candidate.is_relative_to(root) or not candidate.is_file():raise ValueError('稿件必须是写作目录内已存在的文件')
                            item['draft']=str(candidate.relative_to(root))
                        before=item['status']
                        if a.status:item['status']=a.status
                        if a.next is not None:item['next']=a.next
                        item['updated_at']=stamp()
                        item['history'].append({'at':stamp(),'from':before,'to':item['status'],'note':a.note or '', 'publication_confirmed':a.publication_confirmed})
                        save(path,data)
                    result=item
            print(json.dumps(result,ensure_ascii=False,indent=2))
        finally:
            if locked:lock.unlink()
    except (OSError,ValueError,json.JSONDecodeError) as e:p.exit(1,str(e)+'\n')

if __name__=='__main__':main()
