# 来源与能力对应

参考用户提供文章《10个Skill搭建日更爆文的公众号写作系统》及 https://github.com/SpaceZephyr/creator-buddy/tree/main/gzh-Skills ，审阅版本edf46c567ff54b72ee2157d06f3a02dbd67aaa9c。

本版按用户需求重新编写流程和辅助代码，没有复制原作者个人文风、案例、绘图模板或不验证证书的请求实现。原下载留作研究；未来如分发原实现需分别核对授权。

对应：gzh-positioning→账号定位与介绍；baokuan-article-analysis→同行选题分析；gzh-explosive-content-detector→公众号热门样本；gzh-longform-writer→真实经历写长文；gzh-short-post→一个发现写短文；baokuan-title-generator→标题候选与核验；space-gzh-cover→简洁公众号封面；space-chart-image→文章图解与配图；space-text-logic-diagram→段落逻辑图；space-wechat-layout→公众号排版；global-content-search→跨平台素材搜索；xhs-hotnotes→小红书灵感参考。

新增：今日写作推进、素材入库与脱敏、发布复盘。全部为一个主技能中的中文模块，不是15项独立安装技能。第一版检索使用环境现有工具；上游API未迁移或在线验证。封面生成与图片导出依赖环境工具，不自带付费账号。
